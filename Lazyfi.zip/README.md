# Lazyfi
wifi hacking tool
.................
ok, so i am new to the field of ethical hacking and i like scripts.
so i made this script. It will help you hack wpa-wpa2 wifi easyly.

**I AM NOT RESPONSIBLE FOR WHAT YOU DO WITH THIS SCRIPT. BE LEGAL**

REQUIRMENTS
...........
1.Kali linux or similar os.
2.Basic Knowledge of linux.

PROCESS
.......
1.Install the script obviousluy.
2.Run lazy from terminal.
3.Wait until you get the list of available wifi.
4.Make a copy of Bssid and Channel of the wifi you want to Hack.
5.Press Enter to proceed with the script.
6.At this pint you will have a menu.
7.Choose 1 to start hacking.
8.Give the bssid,channel and a name then press enter.
two seperate windows will open now.one will monitor the wifi
and the other will send deauth signals. wait till you get a 
handshek the close the windows.
9.Now you have capture file from that wifi which contains the password. so choose 2 which is the option to crack password.
here you have to give the script a wordlist(rockyou.txt or crackstation.txt) and press enter. this will take time depending on
the quality of the password.so be patient.
10.there are 2 other options as well 3rd option will clean any old capture files and the last option is to stop the script.
